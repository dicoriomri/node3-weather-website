import { W as WebPlugin } from "./index-TS-yPo92.js";
class BrowserWeb extends WebPlugin {
  constructor() {
    super();
    this._lastWindow = null;
  }
  async open(options) {
    this._lastWindow = window.open(options.url, options.windowName || "_blank");
  }
  async close() {
    return new Promise((resolve, reject) => {
      if (this._lastWindow != null) {
        this._lastWindow.close();
        this._lastWindow = null;
        resolve();
      } else {
        reject("No active window to close!");
      }
    });
  }
}
const Browser = new BrowserWeb();
export {
  Browser,
  BrowserWeb
};
