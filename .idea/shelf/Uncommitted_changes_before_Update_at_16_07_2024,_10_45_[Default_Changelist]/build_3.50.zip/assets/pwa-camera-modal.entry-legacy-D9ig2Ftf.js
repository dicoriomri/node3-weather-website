;
(function () {
  System.register(['./index-legacy-CeqFVBPX.js'], function (exports, module) {
    'use strict';

    var h, registerInstance, createEvent;
    return {
      setters: [module => {
        h = module.q;
        registerInstance = module.u;
        createEvent = module.v;
      }],
      execute: function () {
        var __awaiter = undefined && undefined.__awaiter || function (e, t, n, r) {
          function i(e) {
            return e instanceof n ? e : new n(function (t) {
              t(e);
            });
          }
          return new (n || (n = Promise))(function (n, o) {
            function a(e) {
              try {
                c(r.next(e));
              } catch (e) {
                o(e);
              }
            }
            function s(e) {
              try {
                c(r["throw"](e));
              } catch (e) {
                o(e);
              }
            }
            function c(e) {
              e.done ? n(e.value) : i(e.value).then(a, s);
            }
            c((r = r.apply(e, t || [])).next());
          });
        };
        var __generator = undefined && undefined.__generator || function (e, t) {
          var n = {
              label: 0,
              sent: function () {
                if (o[0] & 1) throw o[1];
                return o[1];
              },
              trys: [],
              ops: []
            },
            r,
            i,
            o,
            a;
          return a = {
            next: s(0),
            throw: s(1),
            return: s(2)
          }, typeof Symbol === "function" && (a[Symbol.iterator] = function () {
            return this;
          }), a;
          function s(e) {
            return function (t) {
              return c([e, t]);
            };
          }
          function c(s) {
            if (r) throw new TypeError("Generator is already executing.");
            while (a && (a = 0, s[0] && (n = 0)), n) try {
              if (r = 1, i && (o = s[0] & 2 ? i["return"] : s[0] ? i["throw"] || ((o = i["return"]) && o.call(i), 0) : i.next) && !(o = o.call(i, s[1])).done) return o;
              if (i = 0, o) s = [s[0] & 2, o.value];
              switch (s[0]) {
                case 0:
                case 1:
                  o = s;
                  break;
                case 4:
                  n.label++;
                  return {
                    value: s[1],
                    done: false
                  };
                case 5:
                  n.label++;
                  i = s[1];
                  s = [0];
                  continue;
                case 7:
                  s = n.ops.pop();
                  n.trys.pop();
                  continue;
                default:
                  if (!(o = n.trys, o = o.length > 0 && o[o.length - 1]) && (s[0] === 6 || s[0] === 2)) {
                    n = 0;
                    continue;
                  }
                  if (s[0] === 3 && (!o || s[1] > o[0] && s[1] < o[3])) {
                    n.label = s[1];
                    break;
                  }
                  if (s[0] === 6 && n.label < o[1]) {
                    n.label = o[1];
                    o = s;
                    break;
                  }
                  if (o && n.label < o[2]) {
                    n.label = o[2];
                    n.ops.push(s);
                    break;
                  }
                  if (o[2]) n.ops.pop();
                  n.trys.pop();
                  continue;
              }
              s = t.call(e, n);
            } catch (e) {
              s = [6, e];
              i = 0;
            } finally {
              r = o = 0;
            }
            if (s[0] & 5) throw s[1];
            return {
              value: s[0] ? s[1] : void 0,
              done: true
            };
          }
        };
        var cameraModalCss = ":host{z-index:1000;position:fixed;top:0;left:0;width:100%;height:100%;display:-ms-flexbox;display:flex;contain:strict}.wrapper{-ms-flex:1;flex:1;display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;background-color:rgba(0, 0, 0, 0.15)}.content{-webkit-box-shadow:0px 0px 5px rgba(0, 0, 0, 0.2);box-shadow:0px 0px 5px rgba(0, 0, 0, 0.2);width:600px;height:600px}";
        var PWACameraModal = exports("pwa_camera_modal", function () {
          function e(e) {
            registerInstance(this, e);
            this.onPhoto = createEvent(this, "onPhoto", 7);
            this.noDeviceError = createEvent(this, "noDeviceError", 7);
            this.facingMode = "user";
            this.hidePicker = false;
          }
          e.prototype.present = function () {
            return __awaiter(this, void 0, void 0, function () {
              var e;
              var t = this;
              return __generator(this, function (n) {
                e = document.createElement("pwa-camera-modal-instance");
                e.facingMode = this.facingMode;
                e.hidePicker = this.hidePicker;
                e.addEventListener("onPhoto", function (e) {
                  return __awaiter(t, void 0, void 0, function () {
                    var t;
                    return __generator(this, function (n) {
                      if (!this._modal) {
                        return [2];
                      }
                      t = e.detail;
                      this.onPhoto.emit(t);
                      return [2];
                    });
                  });
                });
                e.addEventListener("noDeviceError", function (e) {
                  return __awaiter(t, void 0, void 0, function () {
                    return __generator(this, function (t) {
                      this.noDeviceError.emit(e);
                      return [2];
                    });
                  });
                });
                document.body.append(e);
                this._modal = e;
                return [2];
              });
            });
          };
          e.prototype.dismiss = function () {
            return __awaiter(this, void 0, void 0, function () {
              return __generator(this, function (e) {
                if (!this._modal) {
                  return [2];
                }
                this._modal && this._modal.parentNode.removeChild(this._modal);
                this._modal = null;
                return [2];
              });
            });
          };
          e.prototype.render = function () {
            return h("div", null);
          };
          return e;
        }());
        PWACameraModal.style = cameraModalCss;
      }
    };
  });
})();
