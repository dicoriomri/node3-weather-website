;
(function () {
  System.register(['./index-legacy-CeqFVBPX.js'], function (exports, module) {
    'use strict';

    var WebPlugin;
    return {
      setters: [module => {
        WebPlugin = module.W;
      }],
      execute: function () {
        class SplashScreenWeb extends WebPlugin {
          async show(_options) {
            return undefined;
          }
          async hide(_options) {
            return undefined;
          }
        }
        exports("SplashScreenWeb", SplashScreenWeb);
      }
    };
  });
})();
