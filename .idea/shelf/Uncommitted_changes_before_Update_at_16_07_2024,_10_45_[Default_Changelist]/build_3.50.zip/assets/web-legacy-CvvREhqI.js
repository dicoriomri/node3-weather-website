;
(function () {
  System.register(['./index-legacy-CeqFVBPX.js'], function (exports, module) {
    'use strict';

    var WebPlugin;
    return {
      setters: [module => {
        WebPlugin = module.W;
      }],
      execute: function () {
        class FCMWeb extends WebPlugin {
          constructor() {
            super({
              name: 'FCM',
              platforms: ['web']
            });
          }
          subscribeTo(_options) {
            throw this.unimplemented('Not implemented on web.');
          }
          unsubscribeFrom(_options) {
            throw this.unimplemented('Not implemented on web.');
          }
          getToken() {
            throw this.unimplemented('Not implemented on web.');
          }
          deleteInstance() {
            throw this.unimplemented('Not implemented on web.');
          }
          setAutoInit(_options) {
            throw this.unimplemented('Not implemented on web.');
          }
          isAutoInitEnabled() {
            throw this.unimplemented('Not implemented on web.');
          }
          refreshToken() {
            throw this.unimplemented('Not implemented on web.');
          }
        }
        exports("FCMWeb", FCMWeb);
        const FCM = exports("FCM", new FCMWeb());
      }
    };
  });
})();
