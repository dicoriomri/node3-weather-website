;
(function () {
  System.register(['./index-legacy-CeqFVBPX.js'], function (exports, module) {
    'use strict';

    var WebPlugin;
    return {
      setters: [module => {
        WebPlugin = module.W;
      }],
      execute: function () {
        class BadgeWeb extends WebPlugin {
          constructor() {
            super();
            this.restore();
          }
          async checkPermissions() {
            return {
              display: 'granted'
            };
          }
          async requestPermissions() {
            return {
              display: 'granted'
            };
          }
          async get() {
            const value = localStorage.getItem(BadgeWeb.STORAGE_KEY);
            const count = value ? parseInt(value, 10) : 0;
            return {
              count
            };
          }
          async set(options) {
            const count = options.count;
            if (count === 0) {
              await navigator.clearAppBadge();
            } else {
              await navigator.setAppBadge(count);
            }
            const value = count.toString();
            localStorage.setItem(BadgeWeb.STORAGE_KEY, value);
          }
          async increase() {
            const {
              count
            } = await this.get();
            await this.set({
              count: count + 1
            });
          }
          async decrease() {
            const {
              count
            } = await this.get();
            if (count < 1) {
              return;
            }
            await this.set({
              count: count - 1
            });
          }
          async clear() {
            await this.set({
              count: 0
            });
          }
          async isSupported() {
            const result = {
              isSupported: 'setAppBadge' in navigator
            };
            return result;
          }
          async restore() {
            const value = localStorage.getItem(BadgeWeb.STORAGE_KEY);
            if (!value) {
              return;
            }
            const count = parseInt(value, 10);
            await navigator.setAppBadge(count);
          }
        }
        exports("BadgeWeb", BadgeWeb);
        BadgeWeb.STORAGE_KEY = 'capacitor.badge';
      }
    };
  });
})();
