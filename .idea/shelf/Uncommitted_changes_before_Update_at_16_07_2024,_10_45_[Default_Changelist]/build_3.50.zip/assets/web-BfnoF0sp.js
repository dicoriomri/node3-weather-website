import { W as WebPlugin } from "./index-TS-yPo92.js";
class WatchWeb extends WebPlugin {
  async setWatchUI(_options) {
    return Promise.reject("method not implemented on web");
  }
  async updateWatchUI(_options) {
    return Promise.reject("method not implemented on web");
  }
  async updateWatchData(_options) {
    return Promise.reject("method not implemented on web");
  }
}
export {
  WatchWeb
};
