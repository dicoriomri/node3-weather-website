;
(function () {
  System.register(['./index-legacy-CeqFVBPX.js'], function (exports, module) {
    'use strict';

    var h, getElement, registerInstance, createEvent;
    return {
      setters: [module => {
        h = module.q;
        getElement = module.t;
        registerInstance = module.u;
        createEvent = module.v;
      }],
      execute: function () {
        var __awaiter = undefined && undefined.__awaiter || function (e, t, n, o) {
          function r(e) {
            return e instanceof n ? e : new n(function (t) {
              t(e);
            });
          }
          return new (n || (n = Promise))(function (n, i) {
            function a(e) {
              try {
                s(o.next(e));
              } catch (e) {
                i(e);
              }
            }
            function c(e) {
              try {
                s(o["throw"](e));
              } catch (e) {
                i(e);
              }
            }
            function s(e) {
              e.done ? n(e.value) : r(e.value).then(a, c);
            }
            s((o = o.apply(e, t || [])).next());
          });
        };
        var __generator = undefined && undefined.__generator || function (e, t) {
          var n = {
              label: 0,
              sent: function () {
                if (i[0] & 1) throw i[1];
                return i[1];
              },
              trys: [],
              ops: []
            },
            o,
            r,
            i,
            a;
          return a = {
            next: c(0),
            throw: c(1),
            return: c(2)
          }, typeof Symbol === "function" && (a[Symbol.iterator] = function () {
            return this;
          }), a;
          function c(e) {
            return function (t) {
              return s([e, t]);
            };
          }
          function s(c) {
            if (o) throw new TypeError("Generator is already executing.");
            while (a && (a = 0, c[0] && (n = 0)), n) try {
              if (o = 1, r && (i = c[0] & 2 ? r["return"] : c[0] ? r["throw"] || ((i = r["return"]) && i.call(r), 0) : r.next) && !(i = i.call(r, c[1])).done) return i;
              if (r = 0, i) c = [c[0] & 2, i.value];
              switch (c[0]) {
                case 0:
                case 1:
                  i = c;
                  break;
                case 4:
                  n.label++;
                  return {
                    value: c[1],
                    done: false
                  };
                case 5:
                  n.label++;
                  r = c[1];
                  c = [0];
                  continue;
                case 7:
                  c = n.ops.pop();
                  n.trys.pop();
                  continue;
                default:
                  if (!(i = n.trys, i = i.length > 0 && i[i.length - 1]) && (c[0] === 6 || c[0] === 2)) {
                    n = 0;
                    continue;
                  }
                  if (c[0] === 3 && (!i || c[1] > i[0] && c[1] < i[3])) {
                    n.label = c[1];
                    break;
                  }
                  if (c[0] === 6 && n.label < i[1]) {
                    n.label = i[1];
                    i = c;
                    break;
                  }
                  if (i && n.label < i[2]) {
                    n.label = i[2];
                    n.ops.push(c);
                    break;
                  }
                  if (i[2]) n.ops.pop();
                  n.trys.pop();
                  continue;
              }
              c = t.call(e, n);
            } catch (e) {
              c = [6, e];
              r = 0;
            } finally {
              o = i = 0;
            }
            if (c[0] & 5) throw c[1];
            return {
              value: c[0] ? c[1] : void 0,
              done: true
            };
          }
        };
        var cameraModalInstanceCss = ":host{z-index:1000;position:fixed;top:0;left:0;width:100%;height:100%;display:-ms-flexbox;display:flex;contain:strict;--inset-width:600px;--inset-height:600px}.wrapper{-ms-flex:1;flex:1;display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;background-color:rgba(0, 0, 0, 0.15)}.content{-webkit-box-shadow:0px 0px 5px rgba(0, 0, 0, 0.2);box-shadow:0px 0px 5px rgba(0, 0, 0, 0.2);width:var(--inset-width);height:var(--inset-height);max-height:100%}@media only screen and (max-width: 600px){.content{width:100%;height:100%}}";
        var PWACameraModal = exports("pwa_camera_modal_instance", function () {
          function e(e) {
            var t = this;
            registerInstance(this, e);
            this.onPhoto = createEvent(this, "onPhoto", 7);
            this.noDeviceError = createEvent(this, "noDeviceError", 7);
            this.handlePhoto = function (e) {
              return __awaiter(t, void 0, void 0, function () {
                return __generator(this, function (t) {
                  this.onPhoto.emit(e);
                  return [2];
                });
              });
            };
            this.handleNoDeviceError = function (e) {
              return __awaiter(t, void 0, void 0, function () {
                return __generator(this, function (t) {
                  this.noDeviceError.emit(e);
                  return [2];
                });
              });
            };
            this.facingMode = "user";
            this.hidePicker = false;
            this.noDevicesText = "No camera found";
            this.noDevicesButtonText = "Choose image";
          }
          e.prototype.handleBackdropClick = function (e) {
            if (e.target !== this.el) {
              this.onPhoto.emit(null);
            }
          };
          e.prototype.handleComponentClick = function (e) {
            e.stopPropagation();
          };
          e.prototype.handleBackdropKeyUp = function (e) {
            if (e.key === "Escape") {
              this.onPhoto.emit(null);
            }
          };
          e.prototype.render = function () {
            var e = this;
            return h("div", {
              class: "wrapper",
              onClick: function (t) {
                return e.handleBackdropClick(t);
              }
            }, h("div", {
              class: "content"
            }, h("pwa-camera", {
              onClick: function (t) {
                return e.handleComponentClick(t);
              },
              facingMode: this.facingMode,
              hidePicker: this.hidePicker,
              handlePhoto: this.handlePhoto,
              handleNoDeviceError: this.handleNoDeviceError,
              noDevicesButtonText: this.noDevicesButtonText,
              noDevicesText: this.noDevicesText
            })));
          };
          Object.defineProperty(e.prototype, "el", {
            get: function () {
              return getElement(this);
            },
            enumerable: false,
            configurable: true
          });
          return e;
        }());
        PWACameraModal.style = cameraModalInstanceCss;
      }
    };
  });
})();
