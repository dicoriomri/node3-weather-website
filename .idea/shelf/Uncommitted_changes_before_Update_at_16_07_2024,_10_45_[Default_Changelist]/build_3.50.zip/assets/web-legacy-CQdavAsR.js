;
(function () {
  System.register(['./index-legacy-CeqFVBPX.js'], function (exports, module) {
    'use strict';

    var WebPlugin;
    return {
      setters: [module => {
        WebPlugin = module.W;
      }],
      execute: function () {
        class InAppReviewWeb extends WebPlugin {
          async requestReview() {
            throw this.unimplemented('Not implemented on web.');
          }
        }
        exports("InAppReviewWeb", InAppReviewWeb);
      }
    };
  });
})();
