import { W as WebPlugin } from "./index-TS-yPo92.js";
class InAppReviewWeb extends WebPlugin {
  async requestReview() {
    throw this.unimplemented("Not implemented on web.");
  }
}
export {
  InAppReviewWeb
};
