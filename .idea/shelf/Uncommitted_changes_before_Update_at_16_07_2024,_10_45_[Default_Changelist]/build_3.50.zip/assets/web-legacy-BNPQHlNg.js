;
(function () {
  System.register(['./index-legacy-CeqFVBPX.js'], function (exports, module) {
    'use strict';

    var WebPlugin;
    return {
      setters: [module => {
        WebPlugin = module.W;
      }],
      execute: function () {
        class WatchWeb extends WebPlugin {
          async setWatchUI(_options) {
            return Promise.reject('method not implemented on web');
          }
          async updateWatchUI(_options) {
            return Promise.reject('method not implemented on web');
          }
          async updateWatchData(_options) {
            return Promise.reject('method not implemented on web');
          }
        }
        exports("WatchWeb", WatchWeb);
      }
    };
  });
})();
